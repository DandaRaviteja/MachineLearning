from flask import Flask, render_template, flash, redirect, url_for, session, logging, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///C:\\Users\\972270\\PycharmProjects\\ExpenseTracker\\database.db'
db = SQLAlchemy(app)


class BillDetailsUpload(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    empName = db.Column(db.String(80))
    Date = db.Column(db.String(20))
    ClientName = db.Column(db.String(80))
    clientRemarks = db.Column(db.String(80))
    clientFollowUp = db.Column(db.String(80))


@app.route("/")
def index():
    return render_template("login.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        uname = request.form["uname"]
        passw = request.form["passw"]

        #login = user.query.filter_by(username=uname, password=passw).first()
        if login is not None:
            return redirect(url_for("index"))
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        uname = request.form['uname']
        mail = request.form['mail']
        passw = request.form['passw']

        register = BillDetailsUpload(username=uname, email=mail, password=passw)
        db.session.add(register)
        db.session.commit()

        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/loginVerify", methods=["GET", "POST"])
def loginVerify():
    if request.form['passw'] == 'ravi' or 'teja' or 'pandi' and request.form['uname'] == 'ravi' or 'teja' or 'pandi':
        return render_template("addBill.html")
    else:
        flash('wrong password!')
        return render_template("loginFailed.html")
    return login()

@app.route("/updateDetails", methods=["GET", "POST"])
def updateDetails():
    if request.method == "POST":
        empname = request.form['empname']
        date = request.form['date']
        clientname = request.form['clientname']
        clientremarks = request.form['clientremarks']
        cfollowup = request.form['cfollowup']
        register = BillDetailsUpload(empName=empname, Date=date,ClientName=clientname, clientRemarks=clientremarks, clientFollowUp=cfollowup)
        db.session.add(register)

        db.session.commit()
        rows = BillDetailsUpload.query.all()
        for row in rows:
            res = row
    return render_template("loginSuccess.html",res=res)

@app.route("/view")
def view():
    rows = BillDetailsUpload.query.all()
    #for row in rows:
     #   db.session.delete(row)
    db.session.commit()
    return render_template("view.html",rows = rows)

if __name__ == "__main__":
    db.create_all()
    app.run(debug=True)